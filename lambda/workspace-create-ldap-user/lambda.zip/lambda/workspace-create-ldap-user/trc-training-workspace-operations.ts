import { Attribute, Change, Client, DN, RDN, } from "ldapts";
import { TerminateRequest, CreateWorkspacesCommand, CreateWorkspacesRequest, WorkSpacesClient, WorkspaceRequest, RegisterWorkspaceDirectoryCommand, ModifyWorkspaceAccessPropertiesCommand, TerminateWorkspacesCommand, DescribeWorkspacesCommand, TerminateWorkspacesRequest, DeregisterWorkspaceDirectoryCommand } from "@aws-sdk/client-workspaces";
import { DeleteDirectoryCommand, DescribeDirectoriesCommand, DirectoryServiceClient, ResetUserPasswordCommand } from "@aws-sdk/client-directory-service";

export interface user_info {
    username: string, email: string, password: string
}
export interface workspace_props {
    directory: string,
    bundle: string,
    domain: string,
    baseDN: string,
    endpointUrl: string,
    adminUser: string,
    adminPassword: string,
    defaultEmail: string
}


const wsclient = new WorkSpacesClient({});
const dsclient = new DirectoryServiceClient({});

// export async function setupTrainingWorkspaces(workspace_props: workspace_props, userAmount: number) {


//     //initial setup
//     await workspace_settings(workspace_props.directory);


//     //get usernames
//     const usernames = get_user_names(userAmount);

//     usernames.forEach(async user => {

//         const password = user + "!";

//         await create_user(workspace_props, {
//             username: user,
//             password: password,
//             email: workspace_props.defaultEmail
//         });

//         await create_workspace(workspace_props, user);

//     });

// }


// export function get_user_names(userAmount: number): Array<string> {

//     var users: Array<string> = [];

//     for (let index = 0; index < userAmount; index++) {

//         users.push("training" + (index + 1).toString().padStart(2, "0"));

//     }

//     return users;
// }




export async function create_workspace(workspace_props: workspace_props, user: string) {
    var array: Array<WorkspaceRequest> = [];

    array.push({
        BundleId: workspace_props.bundle,
        DirectoryId: workspace_props.directory,
        UserName: user,
        WorkspaceProperties: {
            RunningMode: "AutoStop"
        }
    })


    var command = new CreateWorkspacesCommand({
        Workspaces: array
    })

    console.log("creating workspace for user " + user);

    console.log(JSON.stringify(await wsclient.send(command)));
}

// export async function workspace_settings(directoryId: string) {

//     console.log("test version 2");

//     //register directory
//     console.log("registering directory");
//     const register_command = new RegisterWorkspaceDirectoryCommand({
//         DirectoryId: directoryId,
//         EnableWorkDocs: false
//     })
//     try {


//         const result = await wsclient.send(register_command);
//         console.log(JSON.stringify(result));
//     } catch (error) {
//         console.error("Error registering directory: " + error);
//     }

//     try {


//         //allow all access
//         console.log("setting access properties");
//         const settings_command = new ModifyWorkspaceAccessPropertiesCommand({
//             ResourceId: directoryId,
//             WorkspaceAccessProperties: {
//                 DeviceTypeIos: "ALLOW",
//                 DeviceTypeOsx: "ALLOW",
//                 DeviceTypeWeb: "ALLOW",
//                 DeviceTypeWindows: "ALLOW",
//                 DeviceTypeZeroClient: "ALLOW",
//                 DeviceTypeAndroid: "ALLOW",
//                 DeviceTypeChromeOs: "ALLOW",
//             }
//         })
//         const result2 = await wsclient.send(settings_command);
//         console.log(JSON.stringify(result2));

//     } catch (error) {
//         console.error("Error setting access properties: " + error);
//     }
// }

export async function create_user(workspace_props: workspace_props, user_props: user_info) {


    //get directory infos
    const get_dirinfos_command = new DescribeDirectoriesCommand({
        DirectoryIds: [workspace_props.directory]
    });
    const directory_infos = await dsclient.send(get_dirinfos_command);


    const ldapclient = new Client({
        strictDN: false,
        url: 'ldap://' + workspace_props.endpointUrl,
    });

    try {

        await ldapclient.bind("CN=" + workspace_props.adminUser + "," + workspace_props.baseDN, workspace_props.adminPassword);

        console.log("connected");

        await ldapclient.add("CN=" + user_props.username + ", " + workspace_props.baseDN, {
            "sn": [user_props.username],
            "sAMAccountName": [user_props.username],
            "userPrincipalName": [user_props.username + "@" + workspace_props.domain],
            "mail": [user_props.email],
            "givenName": [user_props.username],
            "objectclass": 'user'
        })
            .then(() => {
                console.log("success creating user");
            })
            .catch(err => {
                console.log("error creating user");
                console.log(err);
                throw err;
            });



        //set password
        await change_pwd(user_props.username, user_props.password, workspace_props.directory);

    } catch (ex) {
        // isAuthenticated = false;
        console.log(ex);
        throw ex;
    } finally {
        await ldapclient.unbind();
    }
}

export async function change_pwd(user: string, password: string, directoryID: string) {
    console.log("changing user password");
    const chg_password_command = new ResetUserPasswordCommand({
        DirectoryId: directoryID,
        UserName: user,
        NewPassword: password
    })
    console.log(JSON.stringify(await dsclient.send(chg_password_command)))
}


// export async function delete_all_workspaces(directoryId: string) {


//     console.log("deleting all workspaces");

//     //first get all workspaces
//     const get_command = new DescribeWorkspacesCommand({
//         DirectoryId: directoryId
//     });

//     console.log(directoryId);



//     var term_requests: Array<TerminateRequest>;

//     const get_result = await wsclient.send(get_command).catch(error => {
//         console.error(error);
//         throw error;
//     });


//     console.log(JSON.stringify(get_result.Workspaces));

//     if (get_result.Workspaces !== undefined && get_result.Workspaces.length !== 0) {


//         term_requests = get_result.Workspaces.map(workspace => {
//             console.log("found workspace: " + workspace.WorkspaceId + " of User " + workspace.UserName);
//             return {
//                 WorkspaceId: workspace.WorkspaceId
//             };
//         })

//     }
//     else {
//         const msg = "no workspaces found"
//         console.log(msg);
//         return;

//     }

//     //delete workspaces
//     console.log("deleting workspaces");
//     const register_command = new TerminateWorkspacesCommand({
//         TerminateWorkspaceRequests: term_requests
//     })
//     console.log(JSON.stringify(await wsclient.send(register_command)));
// }


// export async function deregister_directory(directoryId: string) {

//     //first delete all workspaces
//     await delete_all_workspaces(directoryId);


//     //then deregister
//     //register directory
//     console.log("deregistering directory");
//     const register_command = new DeregisterWorkspaceDirectoryCommand({
//         DirectoryId: directoryId
//     });
//     console.log(JSON.stringify(await wsclient.send(register_command)));

// }



