export interface user_info {
    username: string;
    email: string;
    password: string;
}
export interface workspace_props {
    directory: string;
    bundle: string;
    domain: string;
    baseDN: string;
    endpointUrl: string;
    adminUser: string;
    adminPassword: string;
    defaultEmail: string;
}
export declare function create_workspace(workspace_props: workspace_props, user: string): Promise<void>;
export declare function create_user(workspace_props: workspace_props, user_props: user_info): Promise<void>;
export declare function change_pwd(user: string, password: string, directoryID: string): Promise<void>;
