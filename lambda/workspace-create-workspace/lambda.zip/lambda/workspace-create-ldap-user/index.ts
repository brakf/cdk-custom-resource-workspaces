import {
    CloudFormationCustomResourceCreateEvent,

    Callback,
    Context,
    CloudFormationCustomResourceEventCommon,
    CloudFormationCustomResourceEvent,
    CloudFormationCustomResourceResponse,
    CloudFormationCustomResourceSuccessResponse,
    CloudFormationCustomResourceFailedResponse
} from "aws-lambda";

import * as trc_ws_ops from "./trc-training-workspace-operations";

import { GetParameterCommand, Parameter, SSMClient } from "@aws-sdk/client-ssm";

import { DescribeDirectoriesCommand, DirectoryServiceClient } from "@aws-sdk/client-directory-service";
// import { Aws } from "@aws-cdk/core";

exports.handler = async (event: CloudFormationCustomResourceEvent, context: Context, callback: Callback): Promise<CloudFormationCustomResourceResponse> => {

    console.log(JSON.stringify(event));




    // const usernames = trc_ws_ops.get_user_names(Number.parseInt(process.env.userAmount as string));

    var directoryId: string;
    var adminUser: string;
    var adminPasswordParameterName: string;
    var baseDN: string;
    var defaultEmail: string;
    var domain: string;
    var password: string;
    var username: string;



    try {
        directoryId = event.ResourceProperties["directory"];
        adminPasswordParameterName = event.ResourceProperties["adminPasswordParameter"];
        adminUser = event.ResourceProperties["adminUser"];
        baseDN = event.ResourceProperties["baseDN"];
        defaultEmail = event.ResourceProperties["defaultEmail"];
        domain = event.ResourceProperties["domain"];
        password = event.ResourceProperties["password"];
        username = event.ResourceProperties["username"];

    } catch (error) {
        var returndata: CloudFormationCustomResourceResponse = {
            Status: "FAILED",
            Reason: "Not all Parameters Maintained",
            LogicalResourceId: event.LogicalResourceId,
            PhysicalResourceId: "",
            RequestId: event.RequestId,
            StackId: event.StackId
        };

        console.log(JSON.stringify(returndata));
        return returndata;
    }

    //get endpoint Url

    console.log("getting endpoint url");
    const dsClient = new DirectoryServiceClient({});
    const getEndpointUrlCommand = new DescribeDirectoriesCommand({
        DirectoryIds: [event.ResourceProperties["directoryId"] as string]
    });

    var endpoint: Array<string> | undefined;
    try {


        const getEndpointUrlResult = await dsClient.send(getEndpointUrlCommand).catch(error => {
            console.log("error occured during api call");
            throw error;
        });
        const directoryDescribtion = getEndpointUrlResult.DirectoryDescriptions;
        if (directoryDescribtion !== undefined) {
            const directory = directoryDescribtion[0];
            if (directory !== undefined) {
                endpoint = directory.DnsIpAddrs;

            }

        }


        if (endpoint === undefined || endpoint.length === 0) {

            var returnObject: CloudFormationCustomResourceResponse = {
                Status: "FAILED",
                Reason: "Endpoint not found",
                LogicalResourceId: event.LogicalResourceId,
                PhysicalResourceId: directoryId + "+user-" + username,
                RequestId: event.RequestId,
                StackId: event.StackId
            }
            console.log(returnObject);
            return returnObject
        }

    } catch (error) {
        var returnObject: CloudFormationCustomResourceResponse = {
            Status: "FAILED",
            Reason: error,
            LogicalResourceId: event.LogicalResourceId,
            PhysicalResourceId: directoryId + "+user-" + username,
            RequestId: event.RequestId,
            StackId: event.StackId
        }
        console.log(returnObject);
        return returnObject
    }

    const endpointUrl = endpoint[0];
    console.log("endpoint url: " + endpointUrl);


    //get password from SSM Parameter Store
    console.log("admin password");
    const ssmClient = new SSMClient({});

    const getParameterCommand = new GetParameterCommand({
        Name: adminPasswordParameterName
    })
    var adminPasswordParameter: Parameter | undefined;

    await ssmClient.send(getParameterCommand)
        .then(value => {
            adminPasswordParameter = value.Parameter;
        })

        .catch(error => {
            console.log("error fetching password");
            var returnObject: CloudFormationCustomResourceResponse = {
                Status: "FAILED",
                Reason: error,
                LogicalResourceId: event.LogicalResourceId,
                PhysicalResourceId: directoryId + "+user-" + username,
                RequestId: event.RequestId,
                StackId: event.StackId
            }
            console.log(returnObject);
            return returnObject;
        });

    if (adminPasswordParameter?.Value === undefined) {
        var returnObject: CloudFormationCustomResourceResponse = {
            Status: "FAILED",
            Reason: "AdminPassword not found",
            LogicalResourceId: event.LogicalResourceId,
            PhysicalResourceId: directoryId + "+user-" + username,
            RequestId: event.RequestId,
            StackId: event.StackId
        }
        console.log(returnObject);
        return returnObject;
    }

    var workspaceProps: trc_ws_ops.workspace_props = {
        adminUser: "Administrator",
        adminPassword: adminPasswordParameter.Value,
        baseDN: baseDN,
        defaultEmail: defaultEmail,
        bundle: "", //not required
        directory: directoryId,
        domain: domain,
        endpointUrl: endpointUrl



    };



    switch (event.RequestType) {
        case "Create":

            console.log("create user");
            return await trc_ws_ops.create_user(workspaceProps,
                {
                    username: username,
                    password: password,
                    email: defaultEmail
                })
                .then(() => {
                    var returndata: CloudFormationCustomResourceSuccessResponse =
                    {
                        Status: "SUCCESS",
                        Reason: "",
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "+user-" + username,
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })
                .catch(error => {
                    var returndata: CloudFormationCustomResourceFailedResponse =
                    {
                        Status: "FAILED",
                        Reason: error,
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "+user-" + username,
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };

                    console.log(JSON.stringify(returndata));
                    return returndata;
                });

        case "Update":


            break;

        case "Delete":


            //for now ommited. normally, user would automatically be deleted when directory gets deleted

            var returndatadelete: CloudFormationCustomResourceSuccessResponse =
            {
                Status: "SUCCESS",
                Reason: "No deletion took place (by design)",
                LogicalResourceId: event.LogicalResourceId,
                PhysicalResourceId: directoryId + "+user-" + username,
                RequestId: event.RequestId,
                StackId: event.StackId
            };
            console.log(JSON.stringify(returndatadelete));
            return returndatadelete;






            break;
        default:

    }

    var returndata2: CloudFormationCustomResourceFailedResponse = {
        Status: "FAILED",
        Reason: "Weird Reasons...",
        LogicalResourceId: event.LogicalResourceId,
        PhysicalResourceId: directoryId + "+user-" + username,
        RequestId: event.RequestId,
        StackId: event.StackId
    };

    console.log(JSON.stringify(returndata2));
    return returndata2;


}