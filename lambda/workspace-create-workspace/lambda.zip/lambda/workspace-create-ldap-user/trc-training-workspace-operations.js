"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.change_pwd = exports.create_user = exports.create_workspace = void 0;
const ldapts_1 = require("ldapts");
const client_workspaces_1 = require("@aws-sdk/client-workspaces");
const client_directory_service_1 = require("@aws-sdk/client-directory-service");
const wsclient = new client_workspaces_1.WorkSpacesClient({});
const dsclient = new client_directory_service_1.DirectoryServiceClient({});
// export async function setupTrainingWorkspaces(workspace_props: workspace_props, userAmount: number) {
//     //initial setup
//     await workspace_settings(workspace_props.directory);
//     //get usernames
//     const usernames = get_user_names(userAmount);
//     usernames.forEach(async user => {
//         const password = user + "!";
//         await create_user(workspace_props, {
//             username: user,
//             password: password,
//             email: workspace_props.defaultEmail
//         });
//         await create_workspace(workspace_props, user);
//     });
// }
// export function get_user_names(userAmount: number): Array<string> {
//     var users: Array<string> = [];
//     for (let index = 0; index < userAmount; index++) {
//         users.push("training" + (index + 1).toString().padStart(2, "0"));
//     }
//     return users;
// }
async function create_workspace(workspace_props, user) {
    var array = [];
    array.push({
        BundleId: workspace_props.bundle,
        DirectoryId: workspace_props.directory,
        UserName: user,
        WorkspaceProperties: {
            RunningMode: "AutoStop"
        }
    });
    var command = new client_workspaces_1.CreateWorkspacesCommand({
        Workspaces: array
    });
    console.log("creating workspace for user " + user);
    console.log(JSON.stringify(await wsclient.send(command)));
}
exports.create_workspace = create_workspace;
// export async function workspace_settings(directoryId: string) {
//     console.log("test version 2");
//     //register directory
//     console.log("registering directory");
//     const register_command = new RegisterWorkspaceDirectoryCommand({
//         DirectoryId: directoryId,
//         EnableWorkDocs: false
//     })
//     try {
//         const result = await wsclient.send(register_command);
//         console.log(JSON.stringify(result));
//     } catch (error) {
//         console.error("Error registering directory: " + error);
//     }
//     try {
//         //allow all access
//         console.log("setting access properties");
//         const settings_command = new ModifyWorkspaceAccessPropertiesCommand({
//             ResourceId: directoryId,
//             WorkspaceAccessProperties: {
//                 DeviceTypeIos: "ALLOW",
//                 DeviceTypeOsx: "ALLOW",
//                 DeviceTypeWeb: "ALLOW",
//                 DeviceTypeWindows: "ALLOW",
//                 DeviceTypeZeroClient: "ALLOW",
//                 DeviceTypeAndroid: "ALLOW",
//                 DeviceTypeChromeOs: "ALLOW",
//             }
//         })
//         const result2 = await wsclient.send(settings_command);
//         console.log(JSON.stringify(result2));
//     } catch (error) {
//         console.error("Error setting access properties: " + error);
//     }
// }
async function create_user(workspace_props, user_props) {
    //get directory infos
    const get_dirinfos_command = new client_directory_service_1.DescribeDirectoriesCommand({
        DirectoryIds: [workspace_props.directory]
    });
    const directory_infos = await dsclient.send(get_dirinfos_command);
    const ldapclient = new ldapts_1.Client({
        strictDN: false,
        url: 'ldap://' + workspace_props.endpointUrl,
    });
    try {
        await ldapclient.bind("CN=" + workspace_props.adminUser + "," + workspace_props.baseDN, workspace_props.adminPassword);
        console.log("connected");
        await ldapclient.add("CN=" + user_props.username + ", " + workspace_props.baseDN, {
            "sn": [user_props.username],
            "sAMAccountName": [user_props.username],
            "userPrincipalName": [user_props.username + "@" + workspace_props.domain],
            "mail": [user_props.email],
            "givenName": [user_props.username],
            "objectclass": 'user'
        })
            .then(() => {
            console.log("success creating user");
        })
            .catch(err => {
            console.log("error creating user");
            console.log(err);
            throw err;
        });
        //set password
        await change_pwd(user_props.username, user_props.password, workspace_props.directory);
    }
    catch (ex) {
        // isAuthenticated = false;
        console.log(ex);
        throw ex;
    }
    finally {
        await ldapclient.unbind();
    }
}
exports.create_user = create_user;
async function change_pwd(user, password, directoryID) {
    console.log("changing user password");
    const chg_password_command = new client_directory_service_1.ResetUserPasswordCommand({
        DirectoryId: directoryID,
        UserName: user,
        NewPassword: password
    });
    console.log(JSON.stringify(await dsclient.send(chg_password_command)));
}
exports.change_pwd = change_pwd;
// export async function delete_all_workspaces(directoryId: string) {
//     console.log("deleting all workspaces");
//     //first get all workspaces
//     const get_command = new DescribeWorkspacesCommand({
//         DirectoryId: directoryId
//     });
//     console.log(directoryId);
//     var term_requests: Array<TerminateRequest>;
//     const get_result = await wsclient.send(get_command).catch(error => {
//         console.error(error);
//         throw error;
//     });
//     console.log(JSON.stringify(get_result.Workspaces));
//     if (get_result.Workspaces !== undefined && get_result.Workspaces.length !== 0) {
//         term_requests = get_result.Workspaces.map(workspace => {
//             console.log("found workspace: " + workspace.WorkspaceId + " of User " + workspace.UserName);
//             return {
//                 WorkspaceId: workspace.WorkspaceId
//             };
//         })
//     }
//     else {
//         const msg = "no workspaces found"
//         console.log(msg);
//         return;
//     }
//     //delete workspaces
//     console.log("deleting workspaces");
//     const register_command = new TerminateWorkspacesCommand({
//         TerminateWorkspaceRequests: term_requests
//     })
//     console.log(JSON.stringify(await wsclient.send(register_command)));
// }
// export async function deregister_directory(directoryId: string) {
//     //first delete all workspaces
//     await delete_all_workspaces(directoryId);
//     //then deregister
//     //register directory
//     console.log("deregistering directory");
//     const register_command = new DeregisterWorkspaceDirectoryCommand({
//         DirectoryId: directoryId
//     });
//     console.log(JSON.stringify(await wsclient.send(register_command)));
// }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJjLXRyYWluaW5nLXdvcmtzcGFjZS1vcGVyYXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidHJjLXRyYWluaW5nLXdvcmtzcGFjZS1vcGVyYXRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLG1DQUE2RDtBQUM3RCxrRUFBdVY7QUFDdlYsZ0ZBQXlKO0FBaUJ6SixNQUFNLFFBQVEsR0FBRyxJQUFJLG9DQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzFDLE1BQU0sUUFBUSxHQUFHLElBQUksaURBQXNCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFFaEQsd0dBQXdHO0FBR3hHLHNCQUFzQjtBQUN0QiwyREFBMkQ7QUFHM0Qsc0JBQXNCO0FBQ3RCLG9EQUFvRDtBQUVwRCx3Q0FBd0M7QUFFeEMsdUNBQXVDO0FBRXZDLCtDQUErQztBQUMvQyw4QkFBOEI7QUFDOUIsa0NBQWtDO0FBQ2xDLGtEQUFrRDtBQUNsRCxjQUFjO0FBRWQseURBQXlEO0FBRXpELFVBQVU7QUFFVixJQUFJO0FBR0osc0VBQXNFO0FBRXRFLHFDQUFxQztBQUVyQyx5REFBeUQ7QUFFekQsNEVBQTRFO0FBRTVFLFFBQVE7QUFFUixvQkFBb0I7QUFDcEIsSUFBSTtBQUtHLEtBQUssVUFBVSxnQkFBZ0IsQ0FBQyxlQUFnQyxFQUFFLElBQVk7SUFDakYsSUFBSSxLQUFLLEdBQTRCLEVBQUUsQ0FBQztJQUV4QyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ1AsUUFBUSxFQUFFLGVBQWUsQ0FBQyxNQUFNO1FBQ2hDLFdBQVcsRUFBRSxlQUFlLENBQUMsU0FBUztRQUN0QyxRQUFRLEVBQUUsSUFBSTtRQUNkLG1CQUFtQixFQUFFO1lBQ2pCLFdBQVcsRUFBRSxVQUFVO1NBQzFCO0tBQ0osQ0FBQyxDQUFBO0lBR0YsSUFBSSxPQUFPLEdBQUcsSUFBSSwyQ0FBdUIsQ0FBQztRQUN0QyxVQUFVLEVBQUUsS0FBSztLQUNwQixDQUFDLENBQUE7SUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixHQUFHLElBQUksQ0FBQyxDQUFDO0lBRW5ELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUM7QUFwQkQsNENBb0JDO0FBRUQsa0VBQWtFO0FBRWxFLHFDQUFxQztBQUVyQywyQkFBMkI7QUFDM0IsNENBQTRDO0FBQzVDLHVFQUF1RTtBQUN2RSxvQ0FBb0M7QUFDcEMsZ0NBQWdDO0FBQ2hDLFNBQVM7QUFDVCxZQUFZO0FBR1osZ0VBQWdFO0FBQ2hFLCtDQUErQztBQUMvQyx3QkFBd0I7QUFDeEIsa0VBQWtFO0FBQ2xFLFFBQVE7QUFFUixZQUFZO0FBR1osNkJBQTZCO0FBQzdCLG9EQUFvRDtBQUNwRCxnRkFBZ0Y7QUFDaEYsdUNBQXVDO0FBQ3ZDLDJDQUEyQztBQUMzQywwQ0FBMEM7QUFDMUMsMENBQTBDO0FBQzFDLDBDQUEwQztBQUMxQyw4Q0FBOEM7QUFDOUMsaURBQWlEO0FBQ2pELDhDQUE4QztBQUM5QywrQ0FBK0M7QUFDL0MsZ0JBQWdCO0FBQ2hCLGFBQWE7QUFDYixpRUFBaUU7QUFDakUsZ0RBQWdEO0FBRWhELHdCQUF3QjtBQUN4QixzRUFBc0U7QUFDdEUsUUFBUTtBQUNSLElBQUk7QUFFRyxLQUFLLFVBQVUsV0FBVyxDQUFDLGVBQWdDLEVBQUUsVUFBcUI7SUFHckYscUJBQXFCO0lBQ3JCLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxxREFBMEIsQ0FBQztRQUN4RCxZQUFZLEVBQUUsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDO0tBQzVDLENBQUMsQ0FBQztJQUNILE1BQU0sZUFBZSxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBR2xFLE1BQU0sVUFBVSxHQUFHLElBQUksZUFBTSxDQUFDO1FBQzFCLFFBQVEsRUFBRSxLQUFLO1FBQ2YsR0FBRyxFQUFFLFNBQVMsR0FBRyxlQUFlLENBQUMsV0FBVztLQUMvQyxDQUFDLENBQUM7SUFFSCxJQUFJO1FBRUEsTUFBTSxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUV2SCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXpCLE1BQU0sVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRTtZQUM5RSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQzNCLGdCQUFnQixFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUN2QyxtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUM7WUFDekUsTUFBTSxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztZQUMxQixXQUFXLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ2xDLGFBQWEsRUFBRSxNQUFNO1NBQ3hCLENBQUM7YUFDRyxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLE1BQU0sR0FBRyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7UUFJUCxjQUFjO1FBQ2QsTUFBTSxVQUFVLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUV6RjtJQUFDLE9BQU8sRUFBRSxFQUFFO1FBQ1QsMkJBQTJCO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEIsTUFBTSxFQUFFLENBQUM7S0FDWjtZQUFTO1FBQ04sTUFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDN0I7QUFDTCxDQUFDO0FBbERELGtDQWtEQztBQUVNLEtBQUssVUFBVSxVQUFVLENBQUMsSUFBWSxFQUFFLFFBQWdCLEVBQUUsV0FBbUI7SUFDaEYsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3RDLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxtREFBd0IsQ0FBQztRQUN0RCxXQUFXLEVBQUUsV0FBVztRQUN4QixRQUFRLEVBQUUsSUFBSTtRQUNkLFdBQVcsRUFBRSxRQUFRO0tBQ3hCLENBQUMsQ0FBQTtJQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDMUUsQ0FBQztBQVJELGdDQVFDO0FBR0QscUVBQXFFO0FBR3JFLDhDQUE4QztBQUU5QyxpQ0FBaUM7QUFDakMsMERBQTBEO0FBQzFELG1DQUFtQztBQUNuQyxVQUFVO0FBRVYsZ0NBQWdDO0FBSWhDLGtEQUFrRDtBQUVsRCwyRUFBMkU7QUFDM0UsZ0NBQWdDO0FBQ2hDLHVCQUF1QjtBQUN2QixVQUFVO0FBR1YsMERBQTBEO0FBRTFELHVGQUF1RjtBQUd2RixtRUFBbUU7QUFDbkUsMkdBQTJHO0FBQzNHLHVCQUF1QjtBQUN2QixxREFBcUQ7QUFDckQsaUJBQWlCO0FBQ2pCLGFBQWE7QUFFYixRQUFRO0FBQ1IsYUFBYTtBQUNiLDRDQUE0QztBQUM1Qyw0QkFBNEI7QUFDNUIsa0JBQWtCO0FBRWxCLFFBQVE7QUFFUiwwQkFBMEI7QUFDMUIsMENBQTBDO0FBQzFDLGdFQUFnRTtBQUNoRSxvREFBb0Q7QUFDcEQsU0FBUztBQUNULDBFQUEwRTtBQUMxRSxJQUFJO0FBR0osb0VBQW9FO0FBRXBFLG9DQUFvQztBQUNwQyxnREFBZ0Q7QUFHaEQsd0JBQXdCO0FBQ3hCLDJCQUEyQjtBQUMzQiw4Q0FBOEM7QUFDOUMseUVBQXlFO0FBQ3pFLG1DQUFtQztBQUNuQyxVQUFVO0FBQ1YsMEVBQTBFO0FBRTFFLElBQUkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBdHRyaWJ1dGUsIENoYW5nZSwgQ2xpZW50LCBETiwgUkROLCB9IGZyb20gXCJsZGFwdHNcIjtcbmltcG9ydCB7IFRlcm1pbmF0ZVJlcXVlc3QsIENyZWF0ZVdvcmtzcGFjZXNDb21tYW5kLCBDcmVhdGVXb3Jrc3BhY2VzUmVxdWVzdCwgV29ya1NwYWNlc0NsaWVudCwgV29ya3NwYWNlUmVxdWVzdCwgUmVnaXN0ZXJXb3Jrc3BhY2VEaXJlY3RvcnlDb21tYW5kLCBNb2RpZnlXb3Jrc3BhY2VBY2Nlc3NQcm9wZXJ0aWVzQ29tbWFuZCwgVGVybWluYXRlV29ya3NwYWNlc0NvbW1hbmQsIERlc2NyaWJlV29ya3NwYWNlc0NvbW1hbmQsIFRlcm1pbmF0ZVdvcmtzcGFjZXNSZXF1ZXN0LCBEZXJlZ2lzdGVyV29ya3NwYWNlRGlyZWN0b3J5Q29tbWFuZCB9IGZyb20gXCJAYXdzLXNkay9jbGllbnQtd29ya3NwYWNlc1wiO1xuaW1wb3J0IHsgRGVsZXRlRGlyZWN0b3J5Q29tbWFuZCwgRGVzY3JpYmVEaXJlY3Rvcmllc0NvbW1hbmQsIERpcmVjdG9yeVNlcnZpY2VDbGllbnQsIFJlc2V0VXNlclBhc3N3b3JkQ29tbWFuZCB9IGZyb20gXCJAYXdzLXNkay9jbGllbnQtZGlyZWN0b3J5LXNlcnZpY2VcIjtcblxuZXhwb3J0IGludGVyZmFjZSB1c2VyX2luZm8ge1xuICAgIHVzZXJuYW1lOiBzdHJpbmcsIGVtYWlsOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmdcbn1cbmV4cG9ydCBpbnRlcmZhY2Ugd29ya3NwYWNlX3Byb3BzIHtcbiAgICBkaXJlY3Rvcnk6IHN0cmluZyxcbiAgICBidW5kbGU6IHN0cmluZyxcbiAgICBkb21haW46IHN0cmluZyxcbiAgICBiYXNlRE46IHN0cmluZyxcbiAgICBlbmRwb2ludFVybDogc3RyaW5nLFxuICAgIGFkbWluVXNlcjogc3RyaW5nLFxuICAgIGFkbWluUGFzc3dvcmQ6IHN0cmluZyxcbiAgICBkZWZhdWx0RW1haWw6IHN0cmluZ1xufVxuXG5cbmNvbnN0IHdzY2xpZW50ID0gbmV3IFdvcmtTcGFjZXNDbGllbnQoe30pO1xuY29uc3QgZHNjbGllbnQgPSBuZXcgRGlyZWN0b3J5U2VydmljZUNsaWVudCh7fSk7XG5cbi8vIGV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXR1cFRyYWluaW5nV29ya3NwYWNlcyh3b3Jrc3BhY2VfcHJvcHM6IHdvcmtzcGFjZV9wcm9wcywgdXNlckFtb3VudDogbnVtYmVyKSB7XG5cblxuLy8gICAgIC8vaW5pdGlhbCBzZXR1cFxuLy8gICAgIGF3YWl0IHdvcmtzcGFjZV9zZXR0aW5ncyh3b3Jrc3BhY2VfcHJvcHMuZGlyZWN0b3J5KTtcblxuXG4vLyAgICAgLy9nZXQgdXNlcm5hbWVzXG4vLyAgICAgY29uc3QgdXNlcm5hbWVzID0gZ2V0X3VzZXJfbmFtZXModXNlckFtb3VudCk7XG5cbi8vICAgICB1c2VybmFtZXMuZm9yRWFjaChhc3luYyB1c2VyID0+IHtcblxuLy8gICAgICAgICBjb25zdCBwYXNzd29yZCA9IHVzZXIgKyBcIiFcIjtcblxuLy8gICAgICAgICBhd2FpdCBjcmVhdGVfdXNlcih3b3Jrc3BhY2VfcHJvcHMsIHtcbi8vICAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VyLFxuLy8gICAgICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkLFxuLy8gICAgICAgICAgICAgZW1haWw6IHdvcmtzcGFjZV9wcm9wcy5kZWZhdWx0RW1haWxcbi8vICAgICAgICAgfSk7XG5cbi8vICAgICAgICAgYXdhaXQgY3JlYXRlX3dvcmtzcGFjZSh3b3Jrc3BhY2VfcHJvcHMsIHVzZXIpO1xuXG4vLyAgICAgfSk7XG5cbi8vIH1cblxuXG4vLyBleHBvcnQgZnVuY3Rpb24gZ2V0X3VzZXJfbmFtZXModXNlckFtb3VudDogbnVtYmVyKTogQXJyYXk8c3RyaW5nPiB7XG5cbi8vICAgICB2YXIgdXNlcnM6IEFycmF5PHN0cmluZz4gPSBbXTtcblxuLy8gICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCB1c2VyQW1vdW50OyBpbmRleCsrKSB7XG5cbi8vICAgICAgICAgdXNlcnMucHVzaChcInRyYWluaW5nXCIgKyAoaW5kZXggKyAxKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsIFwiMFwiKSk7XG5cbi8vICAgICB9XG5cbi8vICAgICByZXR1cm4gdXNlcnM7XG4vLyB9XG5cblxuXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVfd29ya3NwYWNlKHdvcmtzcGFjZV9wcm9wczogd29ya3NwYWNlX3Byb3BzLCB1c2VyOiBzdHJpbmcpIHtcbiAgICB2YXIgYXJyYXk6IEFycmF5PFdvcmtzcGFjZVJlcXVlc3Q+ID0gW107XG5cbiAgICBhcnJheS5wdXNoKHtcbiAgICAgICAgQnVuZGxlSWQ6IHdvcmtzcGFjZV9wcm9wcy5idW5kbGUsXG4gICAgICAgIERpcmVjdG9yeUlkOiB3b3Jrc3BhY2VfcHJvcHMuZGlyZWN0b3J5LFxuICAgICAgICBVc2VyTmFtZTogdXNlcixcbiAgICAgICAgV29ya3NwYWNlUHJvcGVydGllczoge1xuICAgICAgICAgICAgUnVubmluZ01vZGU6IFwiQXV0b1N0b3BcIlxuICAgICAgICB9XG4gICAgfSlcblxuXG4gICAgdmFyIGNvbW1hbmQgPSBuZXcgQ3JlYXRlV29ya3NwYWNlc0NvbW1hbmQoe1xuICAgICAgICBXb3Jrc3BhY2VzOiBhcnJheVxuICAgIH0pXG5cbiAgICBjb25zb2xlLmxvZyhcImNyZWF0aW5nIHdvcmtzcGFjZSBmb3IgdXNlciBcIiArIHVzZXIpO1xuXG4gICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoYXdhaXQgd3NjbGllbnQuc2VuZChjb21tYW5kKSkpO1xufVxuXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gd29ya3NwYWNlX3NldHRpbmdzKGRpcmVjdG9yeUlkOiBzdHJpbmcpIHtcblxuLy8gICAgIGNvbnNvbGUubG9nKFwidGVzdCB2ZXJzaW9uIDJcIik7XG5cbi8vICAgICAvL3JlZ2lzdGVyIGRpcmVjdG9yeVxuLy8gICAgIGNvbnNvbGUubG9nKFwicmVnaXN0ZXJpbmcgZGlyZWN0b3J5XCIpO1xuLy8gICAgIGNvbnN0IHJlZ2lzdGVyX2NvbW1hbmQgPSBuZXcgUmVnaXN0ZXJXb3Jrc3BhY2VEaXJlY3RvcnlDb21tYW5kKHtcbi8vICAgICAgICAgRGlyZWN0b3J5SWQ6IGRpcmVjdG9yeUlkLFxuLy8gICAgICAgICBFbmFibGVXb3JrRG9jczogZmFsc2Vcbi8vICAgICB9KVxuLy8gICAgIHRyeSB7XG5cblxuLy8gICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB3c2NsaWVudC5zZW5kKHJlZ2lzdGVyX2NvbW1hbmQpO1xuLy8gICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXN1bHQpKTtcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVnaXN0ZXJpbmcgZGlyZWN0b3J5OiBcIiArIGVycm9yKTtcbi8vICAgICB9XG5cbi8vICAgICB0cnkge1xuXG5cbi8vICAgICAgICAgLy9hbGxvdyBhbGwgYWNjZXNzXG4vLyAgICAgICAgIGNvbnNvbGUubG9nKFwic2V0dGluZyBhY2Nlc3MgcHJvcGVydGllc1wiKTtcbi8vICAgICAgICAgY29uc3Qgc2V0dGluZ3NfY29tbWFuZCA9IG5ldyBNb2RpZnlXb3Jrc3BhY2VBY2Nlc3NQcm9wZXJ0aWVzQ29tbWFuZCh7XG4vLyAgICAgICAgICAgICBSZXNvdXJjZUlkOiBkaXJlY3RvcnlJZCxcbi8vICAgICAgICAgICAgIFdvcmtzcGFjZUFjY2Vzc1Byb3BlcnRpZXM6IHtcbi8vICAgICAgICAgICAgICAgICBEZXZpY2VUeXBlSW9zOiBcIkFMTE9XXCIsXG4vLyAgICAgICAgICAgICAgICAgRGV2aWNlVHlwZU9zeDogXCJBTExPV1wiLFxuLy8gICAgICAgICAgICAgICAgIERldmljZVR5cGVXZWI6IFwiQUxMT1dcIixcbi8vICAgICAgICAgICAgICAgICBEZXZpY2VUeXBlV2luZG93czogXCJBTExPV1wiLFxuLy8gICAgICAgICAgICAgICAgIERldmljZVR5cGVaZXJvQ2xpZW50OiBcIkFMTE9XXCIsXG4vLyAgICAgICAgICAgICAgICAgRGV2aWNlVHlwZUFuZHJvaWQ6IFwiQUxMT1dcIixcbi8vICAgICAgICAgICAgICAgICBEZXZpY2VUeXBlQ2hyb21lT3M6IFwiQUxMT1dcIixcbi8vICAgICAgICAgICAgIH1cbi8vICAgICAgICAgfSlcbi8vICAgICAgICAgY29uc3QgcmVzdWx0MiA9IGF3YWl0IHdzY2xpZW50LnNlbmQoc2V0dGluZ3NfY29tbWFuZCk7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3VsdDIpKTtcblxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzZXR0aW5nIGFjY2VzcyBwcm9wZXJ0aWVzOiBcIiArIGVycm9yKTtcbi8vICAgICB9XG4vLyB9XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVfdXNlcih3b3Jrc3BhY2VfcHJvcHM6IHdvcmtzcGFjZV9wcm9wcywgdXNlcl9wcm9wczogdXNlcl9pbmZvKSB7XG5cblxuICAgIC8vZ2V0IGRpcmVjdG9yeSBpbmZvc1xuICAgIGNvbnN0IGdldF9kaXJpbmZvc19jb21tYW5kID0gbmV3IERlc2NyaWJlRGlyZWN0b3JpZXNDb21tYW5kKHtcbiAgICAgICAgRGlyZWN0b3J5SWRzOiBbd29ya3NwYWNlX3Byb3BzLmRpcmVjdG9yeV1cbiAgICB9KTtcbiAgICBjb25zdCBkaXJlY3RvcnlfaW5mb3MgPSBhd2FpdCBkc2NsaWVudC5zZW5kKGdldF9kaXJpbmZvc19jb21tYW5kKTtcblxuXG4gICAgY29uc3QgbGRhcGNsaWVudCA9IG5ldyBDbGllbnQoe1xuICAgICAgICBzdHJpY3RETjogZmFsc2UsXG4gICAgICAgIHVybDogJ2xkYXA6Ly8nICsgd29ya3NwYWNlX3Byb3BzLmVuZHBvaW50VXJsLFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcblxuICAgICAgICBhd2FpdCBsZGFwY2xpZW50LmJpbmQoXCJDTj1cIiArIHdvcmtzcGFjZV9wcm9wcy5hZG1pblVzZXIgKyBcIixcIiArIHdvcmtzcGFjZV9wcm9wcy5iYXNlRE4sIHdvcmtzcGFjZV9wcm9wcy5hZG1pblBhc3N3b3JkKTtcblxuICAgICAgICBjb25zb2xlLmxvZyhcImNvbm5lY3RlZFwiKTtcblxuICAgICAgICBhd2FpdCBsZGFwY2xpZW50LmFkZChcIkNOPVwiICsgdXNlcl9wcm9wcy51c2VybmFtZSArIFwiLCBcIiArIHdvcmtzcGFjZV9wcm9wcy5iYXNlRE4sIHtcbiAgICAgICAgICAgIFwic25cIjogW3VzZXJfcHJvcHMudXNlcm5hbWVdLFxuICAgICAgICAgICAgXCJzQU1BY2NvdW50TmFtZVwiOiBbdXNlcl9wcm9wcy51c2VybmFtZV0sXG4gICAgICAgICAgICBcInVzZXJQcmluY2lwYWxOYW1lXCI6IFt1c2VyX3Byb3BzLnVzZXJuYW1lICsgXCJAXCIgKyB3b3Jrc3BhY2VfcHJvcHMuZG9tYWluXSxcbiAgICAgICAgICAgIFwibWFpbFwiOiBbdXNlcl9wcm9wcy5lbWFpbF0sXG4gICAgICAgICAgICBcImdpdmVuTmFtZVwiOiBbdXNlcl9wcm9wcy51c2VybmFtZV0sXG4gICAgICAgICAgICBcIm9iamVjdGNsYXNzXCI6ICd1c2VyJ1xuICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic3VjY2VzcyBjcmVhdGluZyB1c2VyXCIpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IgY3JlYXRpbmcgdXNlclwiKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgIH0pO1xuXG5cblxuICAgICAgICAvL3NldCBwYXNzd29yZFxuICAgICAgICBhd2FpdCBjaGFuZ2VfcHdkKHVzZXJfcHJvcHMudXNlcm5hbWUsIHVzZXJfcHJvcHMucGFzc3dvcmQsIHdvcmtzcGFjZV9wcm9wcy5kaXJlY3RvcnkpO1xuXG4gICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgLy8gaXNBdXRoZW50aWNhdGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnNvbGUubG9nKGV4KTtcbiAgICAgICAgdGhyb3cgZXg7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgICAgYXdhaXQgbGRhcGNsaWVudC51bmJpbmQoKTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjaGFuZ2VfcHdkKHVzZXI6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZywgZGlyZWN0b3J5SUQ6IHN0cmluZykge1xuICAgIGNvbnNvbGUubG9nKFwiY2hhbmdpbmcgdXNlciBwYXNzd29yZFwiKTtcbiAgICBjb25zdCBjaGdfcGFzc3dvcmRfY29tbWFuZCA9IG5ldyBSZXNldFVzZXJQYXNzd29yZENvbW1hbmQoe1xuICAgICAgICBEaXJlY3RvcnlJZDogZGlyZWN0b3J5SUQsXG4gICAgICAgIFVzZXJOYW1lOiB1c2VyLFxuICAgICAgICBOZXdQYXNzd29yZDogcGFzc3dvcmRcbiAgICB9KVxuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGF3YWl0IGRzY2xpZW50LnNlbmQoY2hnX3Bhc3N3b3JkX2NvbW1hbmQpKSlcbn1cblxuXG4vLyBleHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlX2FsbF93b3Jrc3BhY2VzKGRpcmVjdG9yeUlkOiBzdHJpbmcpIHtcblxuXG4vLyAgICAgY29uc29sZS5sb2coXCJkZWxldGluZyBhbGwgd29ya3NwYWNlc1wiKTtcblxuLy8gICAgIC8vZmlyc3QgZ2V0IGFsbCB3b3Jrc3BhY2VzXG4vLyAgICAgY29uc3QgZ2V0X2NvbW1hbmQgPSBuZXcgRGVzY3JpYmVXb3Jrc3BhY2VzQ29tbWFuZCh7XG4vLyAgICAgICAgIERpcmVjdG9yeUlkOiBkaXJlY3RvcnlJZFxuLy8gICAgIH0pO1xuXG4vLyAgICAgY29uc29sZS5sb2coZGlyZWN0b3J5SWQpO1xuXG5cblxuLy8gICAgIHZhciB0ZXJtX3JlcXVlc3RzOiBBcnJheTxUZXJtaW5hdGVSZXF1ZXN0PjtcblxuLy8gICAgIGNvbnN0IGdldF9yZXN1bHQgPSBhd2FpdCB3c2NsaWVudC5zZW5kKGdldF9jb21tYW5kKS5jYXRjaChlcnJvciA9PiB7XG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuLy8gICAgICAgICB0aHJvdyBlcnJvcjtcbi8vICAgICB9KTtcblxuXG4vLyAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZ2V0X3Jlc3VsdC5Xb3Jrc3BhY2VzKSk7XG5cbi8vICAgICBpZiAoZ2V0X3Jlc3VsdC5Xb3Jrc3BhY2VzICE9PSB1bmRlZmluZWQgJiYgZ2V0X3Jlc3VsdC5Xb3Jrc3BhY2VzLmxlbmd0aCAhPT0gMCkge1xuXG5cbi8vICAgICAgICAgdGVybV9yZXF1ZXN0cyA9IGdldF9yZXN1bHQuV29ya3NwYWNlcy5tYXAod29ya3NwYWNlID0+IHtcbi8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZm91bmQgd29ya3NwYWNlOiBcIiArIHdvcmtzcGFjZS5Xb3Jrc3BhY2VJZCArIFwiIG9mIFVzZXIgXCIgKyB3b3Jrc3BhY2UuVXNlck5hbWUpO1xuLy8gICAgICAgICAgICAgcmV0dXJuIHtcbi8vICAgICAgICAgICAgICAgICBXb3Jrc3BhY2VJZDogd29ya3NwYWNlLldvcmtzcGFjZUlkXG4vLyAgICAgICAgICAgICB9O1xuLy8gICAgICAgICB9KVxuXG4vLyAgICAgfVxuLy8gICAgIGVsc2Uge1xuLy8gICAgICAgICBjb25zdCBtc2cgPSBcIm5vIHdvcmtzcGFjZXMgZm91bmRcIlxuLy8gICAgICAgICBjb25zb2xlLmxvZyhtc2cpO1xuLy8gICAgICAgICByZXR1cm47XG5cbi8vICAgICB9XG5cbi8vICAgICAvL2RlbGV0ZSB3b3Jrc3BhY2VzXG4vLyAgICAgY29uc29sZS5sb2coXCJkZWxldGluZyB3b3Jrc3BhY2VzXCIpO1xuLy8gICAgIGNvbnN0IHJlZ2lzdGVyX2NvbW1hbmQgPSBuZXcgVGVybWluYXRlV29ya3NwYWNlc0NvbW1hbmQoe1xuLy8gICAgICAgICBUZXJtaW5hdGVXb3Jrc3BhY2VSZXF1ZXN0czogdGVybV9yZXF1ZXN0c1xuLy8gICAgIH0pXG4vLyAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoYXdhaXQgd3NjbGllbnQuc2VuZChyZWdpc3Rlcl9jb21tYW5kKSkpO1xuLy8gfVxuXG5cbi8vIGV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXJlZ2lzdGVyX2RpcmVjdG9yeShkaXJlY3RvcnlJZDogc3RyaW5nKSB7XG5cbi8vICAgICAvL2ZpcnN0IGRlbGV0ZSBhbGwgd29ya3NwYWNlc1xuLy8gICAgIGF3YWl0IGRlbGV0ZV9hbGxfd29ya3NwYWNlcyhkaXJlY3RvcnlJZCk7XG5cblxuLy8gICAgIC8vdGhlbiBkZXJlZ2lzdGVyXG4vLyAgICAgLy9yZWdpc3RlciBkaXJlY3Rvcnlcbi8vICAgICBjb25zb2xlLmxvZyhcImRlcmVnaXN0ZXJpbmcgZGlyZWN0b3J5XCIpO1xuLy8gICAgIGNvbnN0IHJlZ2lzdGVyX2NvbW1hbmQgPSBuZXcgRGVyZWdpc3RlcldvcmtzcGFjZURpcmVjdG9yeUNvbW1hbmQoe1xuLy8gICAgICAgICBEaXJlY3RvcnlJZDogZGlyZWN0b3J5SWRcbi8vICAgICB9KTtcbi8vICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShhd2FpdCB3c2NsaWVudC5zZW5kKHJlZ2lzdGVyX2NvbW1hbmQpKSk7XG5cbi8vIH1cblxuXG5cbiJdfQ==