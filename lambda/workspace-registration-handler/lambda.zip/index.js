"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var trc_ws_ops = __importStar(require("./trc-training-workspace-operations"));
// import { GetParameterCommand, SSMClient } from "@aws-sdk/client-ssm";
// import { DescribeDirectoriesCommand, DirectoryServiceClient } from "@aws-sdk/client-directory-service";
// import { Aws } from "@aws-cdk/core";
exports.handler = function (event, context, callback) { return __awaiter(void 0, void 0, void 0, function () {
    var returndata, directoryId, _a, returndata2;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                console.log(JSON.stringify(event));
                // //get password from SSM Parameter Store
                // const ssmClient = new SSMClient({});
                // const getParameterCommand = new GetParameterCommand({
                //     Name: process.env.AdminPasswordParameterName
                // })
                // const adminPassword = await ssmClient.send(getParameterCommand);
                // //get endpoint Url
                // const dsClient = new DirectoryServiceClient({});
                // const getEndpointUrlCommand = new DescribeDirectoriesCommand({
                //     DirectoryIds: [process.env.directory as string]
                // });
                // var endpoint: Array<string> | undefined;
                // const directoryDescribtion = await (await dsClient.send(getEndpointUrlCommand)).DirectoryDescriptions;
                // if (directoryDescribtion !== undefined) {
                //     const directory = directoryDescribtion[0];
                //     if (directory !== undefined) {
                //         endpoint = directory.DnsIpAddrs;
                //     }
                // }
                // if (endpoint === undefined) {
                //     var returnObject: CloudFormationCustomResourceResponse = {
                //         Status: "FAILED",
                //         Reason: "Endpoint not found",
                //         LogicalResourceId: event.LogicalResourceId,
                //         PhysicalResourceId: "",
                //         RequestId: "",
                //         StackId: ""
                //     }
                //     return return
                // }
                // if (adminPassword.Parameter?.Value === undefined) {
                //     return callback("AdminPassword not found");
                // }
                // var workspaceProps: trc_ws_ops.workspace_props = {
                //     domain: process.env.domain as string,
                //     endpointUrl: endpoint[0],
                //     adminUser: "Administrator",
                //     baseDN: process.env.baseDN as string,
                //     bundle: process.env.bundle as string,
                //     defaultEmail: process.env.defaultEmail as string,
                //     directory: process.env.directory as string,
                //     adminPassword: adminPassword.Parameter.Value
                // };
                // const usernames = trc_ws_ops.get_user_names(Number.parseInt(process.env.userAmount as string));
                if (event.ResourceProperties["directory"] === undefined) {
                    returndata = {
                        Status: "FAILED",
                        Reason: "Directory ID not provided",
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: "",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return [2 /*return*/, returndata];
                }
                directoryId = event.ResourceProperties["directory"];
                _a = event.RequestType;
                switch (_a) {
                    case "Create": return [3 /*break*/, 1];
                    case "Update": return [3 /*break*/, 3];
                    case "Delete": return [3 /*break*/, 4];
                }
                return [3 /*break*/, 6];
            case 1: return [4 /*yield*/, trc_ws_ops.workspace_settings(directoryId)
                    .then(function () {
                    var returndata = {
                        Status: "SUCCESS",
                        Reason: "",
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })
                    .catch(function (error) {
                    var returndata = {
                        Status: "FAILED",
                        Reason: error,
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })];
            case 2: return [2 /*return*/, _b.sent()];
            case 3: return [3 /*break*/, 6];
            case 4: return [4 /*yield*/, trc_ws_ops.delete_all_workspaces(directoryId).then(function () { return __awaiter(void 0, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0: return [4 /*yield*/, trc_ws_ops.deregister_directory(directoryId).then(function () {
                                    var returndata = {
                                        Status: "SUCCESS",
                                        Reason: "",
                                        LogicalResourceId: event.LogicalResourceId,
                                        PhysicalResourceId: directoryId + "registration",
                                        RequestId: event.RequestId,
                                        StackId: event.StackId
                                    };
                                    console.log(JSON.stringify(returndata));
                                    return returndata;
                                })
                                    .catch(function (error) {
                                    var returndata = {
                                        Status: "FAILED",
                                        Reason: error,
                                        LogicalResourceId: event.LogicalResourceId,
                                        PhysicalResourceId: directoryId + "registration",
                                        RequestId: event.RequestId,
                                        StackId: event.StackId
                                    };
                                    console.log(JSON.stringify(returndata));
                                    return returndata;
                                })];
                            case 1: return [2 /*return*/, _a.sent()];
                        }
                    });
                }); })
                    .catch(function (error) {
                    var returndata = {
                        Status: "FAILED",
                        Reason: error,
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })];
            case 5: return [2 /*return*/, _b.sent()];
            case 6:
                returndata2 = {
                    Status: "FAILED",
                    Reason: "Weird Reasons...",
                    LogicalResourceId: event.LogicalResourceId,
                    PhysicalResourceId: directoryId + "registration",
                    RequestId: event.RequestId,
                    StackId: event.StackId
                };
                console.log(JSON.stringify(returndata2));
                return [2 /*return*/, returndata2];
        }
    });
}); };
