import {
    CloudFormationCustomResourceCreateEvent,

    Callback,
    Context,
    CloudFormationCustomResourceEventCommon,
    CloudFormationCustomResourceEvent,
    CloudFormationCustomResourceResponse,
    CloudFormationCustomResourceSuccessResponse,
    CloudFormationCustomResourceFailedResponse
} from "aws-lambda";

import * as trc_ws_ops from "./trc-training-workspace-operations";

// import { GetParameterCommand, SSMClient } from "@aws-sdk/client-ssm";

// import { DescribeDirectoriesCommand, DirectoryServiceClient } from "@aws-sdk/client-directory-service";
// import { Aws } from "@aws-cdk/core";

exports.handler = async (event: CloudFormationCustomResourceEvent, context: Context, callback: Callback): Promise<CloudFormationCustomResourceResponse> => {

    console.log(JSON.stringify(event));

    // //get password from SSM Parameter Store
    // const ssmClient = new SSMClient({});

    // const getParameterCommand = new GetParameterCommand({
    //     Name: process.env.AdminPasswordParameterName
    // })
    // const adminPassword = await ssmClient.send(getParameterCommand);

    // //get endpoint Url

    // const dsClient = new DirectoryServiceClient({});

    // const getEndpointUrlCommand = new DescribeDirectoriesCommand({
    //     DirectoryIds: [process.env.directory as string]
    // });





    // var endpoint: Array<string> | undefined;

    // const directoryDescribtion = await (await dsClient.send(getEndpointUrlCommand)).DirectoryDescriptions;
    // if (directoryDescribtion !== undefined) {
    //     const directory = directoryDescribtion[0];
    //     if (directory !== undefined) {
    //         endpoint = directory.DnsIpAddrs;

    //     }

    // }


    // if (endpoint === undefined) {

    //     var returnObject: CloudFormationCustomResourceResponse = {
    //         Status: "FAILED",
    //         Reason: "Endpoint not found",
    //         LogicalResourceId: event.LogicalResourceId,
    //         PhysicalResourceId: "",
    //         RequestId: "",
    //         StackId: ""
    //     }
    //     return return
    // }

    // if (adminPassword.Parameter?.Value === undefined) {
    //     return callback("AdminPassword not found");
    // }

    // var workspaceProps: trc_ws_ops.workspace_props = {
    //     domain: process.env.domain as string,
    //     endpointUrl: endpoint[0],
    //     adminUser: "Administrator",
    //     baseDN: process.env.baseDN as string,
    //     bundle: process.env.bundle as string,
    //     defaultEmail: process.env.defaultEmail as string,
    //     directory: process.env.directory as string,
    //     adminPassword: adminPassword.Parameter.Value
    // };


    // const usernames = trc_ws_ops.get_user_names(Number.parseInt(process.env.userAmount as string));

    if (event.ResourceProperties["directory"] === undefined) {




        var returndata: CloudFormationCustomResourceResponse = {
            Status: "FAILED",
            Reason: "Directory ID not provided",
            LogicalResourceId: event.LogicalResourceId,
            PhysicalResourceId: "",
            RequestId: event.RequestId,
            StackId: event.StackId
        };

        console.log(JSON.stringify(returndata));
        return returndata;
    }

    const directoryId = event.ResourceProperties["directory"];




    switch (event.RequestType) {
        case "Create":


            return await trc_ws_ops.workspace_settings(directoryId)
                .then(() => {
                    var returndata: CloudFormationCustomResourceSuccessResponse =
                    {
                        Status: "SUCCESS",
                        Reason: "",
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })
                .catch(error => {
                    var returndata: CloudFormationCustomResourceFailedResponse =
                    {
                        Status: "FAILED",
                        Reason: error,
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };

                    console.log(JSON.stringify(returndata));
                    return returndata;
                });






        // try {
        //     usernames.forEach(async user => {

        //         const password = user + "!";

        //         await trc_ws_ops.create_user(workspaceProps, {
        //             username: user,
        //             password: password,
        //             email: workspaceProps.defaultEmail
        //         });

        //         await trc_ws_ops.create_workspace(workspaceProps, user);

        //     });


        // } catch (error) {

        // }

        // break;

        case "Update":


            break;
        // case "Update":

        //     break;
        case "Delete":



            return await trc_ws_ops.delete_all_workspaces(directoryId).then(async () => {
                return await trc_ws_ops.deregister_directory(directoryId).then(() => {
                    var returndata: CloudFormationCustomResourceSuccessResponse =
                    {
                        Status: "SUCCESS",
                        Reason: "",
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };
                    console.log(JSON.stringify(returndata));
                    return returndata;
                })
                    .catch(error => {
                        var returndata: CloudFormationCustomResourceFailedResponse =
                        {
                            Status: "FAILED",
                            Reason: error,
                            LogicalResourceId: event.LogicalResourceId,
                            PhysicalResourceId: directoryId + "registration",
                            RequestId: event.RequestId,
                            StackId: event.StackId
                        };

                        console.log(JSON.stringify(returndata));
                        return returndata;
                    });


            })
                .catch(error => {
                    var returndata: CloudFormationCustomResourceFailedResponse =
                    {
                        Status: "FAILED",
                        Reason: error,
                        LogicalResourceId: event.LogicalResourceId,
                        PhysicalResourceId: directoryId + "registration",
                        RequestId: event.RequestId,
                        StackId: event.StackId
                    };

                    console.log(JSON.stringify(returndata));
                    return returndata;
                });;



            break;
        default:

    }

    var returndata2: CloudFormationCustomResourceFailedResponse = {
        Status: "FAILED",
        Reason: "Weird Reasons...",
        LogicalResourceId: event.LogicalResourceId,
        PhysicalResourceId: directoryId + "registration",
        RequestId: event.RequestId,
        StackId: event.StackId
    };

    console.log(JSON.stringify(returndata2));
    return returndata2;


}